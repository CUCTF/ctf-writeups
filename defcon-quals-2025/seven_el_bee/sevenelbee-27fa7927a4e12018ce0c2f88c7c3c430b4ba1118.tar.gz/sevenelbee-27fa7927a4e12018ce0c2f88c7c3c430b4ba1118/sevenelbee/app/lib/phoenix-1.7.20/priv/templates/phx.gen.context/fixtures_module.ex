defmodule <%= inspect context.module %>Fixtures do
  @moduledoc """
  This module defines test helpers for creating
  entities via the `<%= inspect context.module %>` context.
  """
end
