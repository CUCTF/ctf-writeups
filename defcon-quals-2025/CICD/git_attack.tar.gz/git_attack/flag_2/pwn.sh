#!/bin/bash
secrets access flag2